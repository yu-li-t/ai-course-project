# 本地部署说明（Windows）

> 本仓库内容是 [Mall4j 开源版](https://gitee.com/gz-yami/mall4j) 的一份本地部署副本，**原始代码版权归原作者所有，遵循 AGPLv3 协议**（见 `LICENSE`）。
> 本副本仅额外增加了 Windows 一键启停脚本与本文档，未改动业务代码。

## 一键启动

前置条件：已安装 **Docker Desktop**、**Node.js 20.19+/22.12+**、**pnpm 7+**、**JDK 17**。

双击运行根目录的 `启动商城.bat`，等待约 30–60 秒后即可访问：

| 用途 | 地址 |
| --- | --- |
| H5 商城前台 | http://localhost/ |
| 管理后台 | http://127.0.0.1:9527/ |
| 接口文档（管理端） | http://127.0.0.1:8085/doc.html |
| 接口文档（用户端） | http://127.0.0.1:8086/doc.html |

后台账号：`admin` / `123456`

停止：双击 `停止商城.bat`（按端口 8085/8086/9527/80 精确终止，不会误杀其它 Node/Java 程序）。

## 端口与组件

| 服务 | 端口 | 说明 |
| --- | --- | --- |
| MySQL 5.7（Docker） | 3306 | 库 `yami_shops`，root/root，数据卷 `mall4j-mysql-data` |
| Redis 5.0.4（Docker） | 6379 | 缓存与登录态 |
| `yami-shop-admin` | 8085 | 管理端接口 |
| `yami-shop-api` | 8086 | 用户端接口 |
| `front-end/mall4v` | 9527 | 管理后台页面 |
| `front-end/mall4uni` | 80 | H5 商城前台 |

## 手动启动步骤

```powershell
# 1. 数据库（首次会自动建库并导入 db/yami_shop.sql）
docker run -d --name mall4j-mysql -e MYSQL_ROOT_PASSWORD=root -p 3306:3306 `
  -v mall4j-mysql-data:/var/lib/mysql `
  -v "$PWD/db/yami_shop.sql":/docker-entrypoint-initdb.d/yami_shop.sql:ro `
  mysql:5.7 --lower_case_table_names=1

docker run -d --name mall4j-redis -p 6379:6379 redis:5.0.4

# 2. 打包后端（需 JDK 17 + Maven）
mvn clean package -DskipTests

# 3. 启动后端
java -jar yami-shop-admin/target/yami-shop-admin-0.0.1-SNAPSHOT.jar --server.port=8085
java -jar yami-shop-api/target/yami-shop-api-0.0.1-SNAPSHOT.jar --server.port=8086

# 4. 启动前端
cd front-end/mall4v   && pnpm i && pnpm run build && pnpm exec vite preview --port 9527
cd front-end/mall4uni && pnpm i && pnpm run dev:h5
```

## 三个已知的坑

1. **`SERVER__PORT` 环境变量会覆盖端口**：Spring Boot 的宽松绑定会把 `SERVER__PORT` 解析为 `server.port`，若环境中存在该变量，后端会去占用别的端口而启动失败。启动时显式加 `--server.port=8085` 即可绕过。
2. **管理后台不要用 `pnpm run dev`**：其 Vite 配置把 element-plus 全量组件展开做依赖预构建，冷启动会长时间无响应。改用 `pnpm run build` + `vite preview`，1 分钟左右完成。
3. **本机有 HTTP 代理时用 `curl --noproxy '*'` 检测服务**，否则会拿到 502 误判为未启动。

## 其它说明

- 开源版支付为模拟实现（下单后直接标记成功，回调代码处于注释状态），不可用于生产支付。
- 商品图片指向 `https://img.mall4j.com/`，看图需要联网。
- 商用（闭源）需联系 [Mall4j 官网](https://www.mall4j.com) 取得商业授权。
