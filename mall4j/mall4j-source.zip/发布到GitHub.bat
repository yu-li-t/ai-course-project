@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"

echo ==========================================
echo   发布到 GitHub :  yu-li-t/mall4j
echo ==========================================
echo.
echo 本脚本分两步，全程约 1 分钟。
echo.
echo [1/2] 接下来会打开 GitHub 创建仓库页面，
echo       请在页面上直接点 "Create repository"。
echo       注意：不要勾选 README / .gitignore / License 任何一项。
echo.
pause

start "" "https://github.com/new?name=mall4j&visibility=public&description=Mall4j%20Java%20%E5%95%86%E5%9F%8E%E7%B3%BB%E7%BB%9F%20-%20%E6%9C%AC%E5%9C%B0%E9%83%A8%E7%BD%B2%E7%89%88"

echo.
echo       仓库创建好后，回到这个窗口继续。
echo.
pause

echo.
echo [2/2] 正在推送代码（约 1249 个文件）...
echo       若浏览器弹出 GitHub 登录/授权，请点确认。
echo.

git push -u origin main

if errorlevel 1 (
    echo.
    echo [未完成] 推送失败，常见原因：
    echo   1. 网页上的仓库还没创建好，或名字不是 mall4j
    echo   2. 授权窗口被取消
    echo   3. 网络连不上 GitHub
    echo.
    echo 确认后重新双击本脚本即可，已推送过的部分不会重复上传。
) else (
    echo.
    echo [完成] 代码已推送：
    echo       https://github.com/yu-li-t/mall4j
)

echo.
pause
