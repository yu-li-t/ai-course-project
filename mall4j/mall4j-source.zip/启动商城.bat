@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion

set "PROJECT=%~dp0"

REM 优先使用部署时安装的 JDK 17；若不存在则回退到 JAVA_HOME
set "JAVA=%USERPROFILE%\.workbuddy\binaries\java\jdk-17.0.20.1+1\bin\java.exe"
if not exist "%JAVA%" if defined JAVA_HOME set "JAVA=%JAVA_HOME%\bin\java.exe"

echo ==========================================
echo   Mall4j 商城 - 一键启动
echo ==========================================
echo.

if not exist "%JAVA%" (
    echo [错误] 未找到 java.exe。请先安装 JDK 17，并设置环境变量 JAVA_HOME。
    echo        默认查找路径: %USERPROFILE%\.workbuddy\binaries\java\jdk-17.0.20.1+1
    pause
    exit /b 1
)

echo [1/5] 启动 MySQL 与 Redis (Docker) ...
docker start mall4j-mysql >nul 2>&1
docker start mall4j-redis >nul 2>&1
if errorlevel 1 (
    echo   [提示] 容器启动异常，请确认 Docker Desktop 已运行。
) else (
    echo   MySQL 3306 / Redis 6379 已就绪。
)
echo.

echo [2/5] 启动管理端后台接口 (8085) ...
start "mall4j-admin(8085)" "%JAVA%" -jar "%PROJECT%yami-shop-admin\target\yami-shop-admin-0.0.1-SNAPSHOT.jar" --server.port=8085
echo.

echo [3/5] 启动用户端商城接口 (8086) ...
start "mall4j-api(8086)" "%JAVA%" -jar "%PROJECT%yami-shop-api\target\yami-shop-api-0.0.1-SNAPSHOT.jar" --server.port=8086
echo.

echo [4/5] 启动 H5 商城前台 (80) ...
start "mall4j-h5(80)" cmd /c "cd /d %PROJECT%front-end\mall4uni && pnpm run dev:h5"
echo.

echo [5/5] 启动管理后台页面 (9527) ...
start "mall4j-admin-web(9527)" cmd /c "cd /d %PROJECT%front-end\mall4v && pnpm exec vite preview --port 9527 --host"
echo.

echo ==========================================
echo   启动命令已下发，请等待约 30-60 秒
echo ------------------------------------------
echo   H5 商城前台:     http://localhost/
echo   管理后台:        http://127.0.0.1:9527
echo   后台账号:        admin / 123456
echo   接口文档(管理端): http://127.0.0.1:8085/doc.html
echo   接口文档(用户端): http://127.0.0.1:8086/doc.html
echo ==========================================
echo.
pause
