@echo off
chcp 65001 >nul
setlocal

echo 正在停止 Mall4j 相关服务 (仅按端口精确定位) ...

for %%P in (8085 8086 9527 80) do (
    for /f "tokens=5" %%a in ('netstat -ano ^| findstr ":%%P" ^| findstr LISTENING') do (
        echo   停止端口 %%P 上的进程 %%a
        taskkill /PID %%a /F >nul 2>&1
    )
)

echo.
echo 停止 Docker 数据库容器 ...
docker stop mall4j-mysql >nul 2>&1
docker stop mall4j-redis >nul 2>&1

echo.
echo 已停止。数据保存在 Docker 卷 mall4j-mysql-data 中，下次启动不会丢失。
echo.
pause
